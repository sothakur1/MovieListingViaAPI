//
//  MovieListApp.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/25/24.
//

import SwiftUI

@main
struct MovieListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
