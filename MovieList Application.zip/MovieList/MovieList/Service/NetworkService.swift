//
//  NetworkService.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/25/24.
//

import Foundation

class NetworkService {
    func fetchMovies(completion: @escaping (Result<[Movie], Error>) -> Void) {
       
        let urlString = "https://api.themoviedb.org/3/movie/now_playing?api_key=3f1af7b9463ff0d58edaf33d21bf7fec"
       
        //3f1af7b9463ff0d58edaf33d21bf7fec
        
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else { return }
            
            do {
                let moviesResponse = try JSONDecoder().decode(MoviesResponse.self, from: data)
                print("Fetched \(moviesResponse.results.count) movies.")
                completion(.success(moviesResponse.results))
            } catch {
                completion(.failure(error))
            }
        }.resume()
        
        
       
    }
}
