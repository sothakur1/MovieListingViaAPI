//
//  MovieResponse.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/25/24.
//

import Foundation

struct MoviesResponse: Decodable {
    let dates: Dates
    let page: Int
    let results: [Movie]
    let totalPages: Int
    let totalResults: Int

    enum CodingKeys: String, CodingKey {
        case dates, page, results
        case totalPages = "total_pages"
        case totalResults = "total_results"
    }
}

struct Dates: Decodable {
    let maximum: String
    let minimum: String
}
