//
//  Movie.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/25/24.
//

//import Foundation
//
//struct Movie: Decodable, Identifiable {
//    let id: Int
//    let title: String
//    let backdropPath: String?
//    let posterPath: String?
//    let overview: String
//    let voteAverage: Double
//    let releaseDate: String
//    let popularity: Double
//    let voteCount: Int
//    
//    enum CodingKeys: String, CodingKey {
//        case id, title, backdropPath, posterPath, overview, voteAverage, releaseDate, popularity, voteCount
//    }
//}


import Foundation

struct Movie: Decodable, Identifiable {
    let id: Int
    let title: String
    let backdropPath: String?
    let posterPath: String?
    let overview: String
    let voteAverage: Double
    let releaseDate: String
    
    enum CodingKeys: String, CodingKey {
        case id, title, overview, voteAverage = "vote_average", releaseDate = "release_date"
        case backdropPath = "backdrop_path", posterPath = "poster_path"
    }
}
