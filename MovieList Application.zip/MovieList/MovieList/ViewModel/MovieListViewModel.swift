//
//  MovieListViewModel.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/25/24.
//

import Foundation

class MovieListViewModel: ObservableObject {
    @Published var movies: [Movie] = []
    
    func fetchMovies() {
        NetworkService().fetchMovies { [weak self] result in
            switch result {
            case .success(let movies):
                DispatchQueue.main.async {
                    self?.movies = movies
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
