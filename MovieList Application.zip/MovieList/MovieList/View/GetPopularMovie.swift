//
//  GetPopularMovie.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/29/24.
//

import SwiftUI

struct GetPopularMovie: View {
    @ObservedObject var viewModel = MovieListViewModel()

    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.movies) { movie in
                    NavigationLink(destination: MovieDetailView(movie: movie)) {
                        MovieRow(movie: movie)
                    }
                }
                .onDelete(perform: deleteMovies)
            }
            .navigationTitle("Now Playing")
        }
        .onAppear {
            viewModel.fetchMovies()
        }
    }

    private func deleteMovies(at offsets: IndexSet) {
        viewModel.movies.remove(atOffsets: offsets)
    }
}

#Preview {
    GetPopularMovie()
}
