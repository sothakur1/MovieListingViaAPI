//
//  MovieRow.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/25/24.
//

import Foundation
import SwiftUI

struct MovieRow: View {
    var movie: Movie

    var body: some View {
        HStack {
            // Check if posterPath exists and unwrap it safely
            if let posterPath = movie.posterPath, let url = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)") {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .success(let image):
                        image.resizable()
                             .aspectRatio(contentMode: .fill)
                             .frame(width: 50, height: 75)
                             .cornerRadius(4)
                    case .failure:
                        Image(systemName: "film")
                            .font(.title)
                    @unknown default:
                        EmptyView()
                    }
                }
            } else {
                Image(systemName: "film")
                    .font(.title)
                    .frame(width: 50, height: 75)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(movie.title)
                    .fontWeight(.medium)
                Text(movie.releaseDate)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding(.leading, 8)
        }
    }
}


