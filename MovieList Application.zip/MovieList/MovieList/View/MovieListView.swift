//
//  MovieListView.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/25/24.
//

import Foundation
import SwiftUI

struct MovieListView: View {
    @ObservedObject var viewModel = MovieListViewModel()
    
    let columns: [GridItem] = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                if viewModel.movies.isEmpty {
                    VStack {
                        ProgressView("Loading movies...")
                            .scaleEffect(1.5, anchor: .center)
                            .padding()
                    }
                } else {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(viewModel.movies) { movie in
                            MovieGridItem(movie: movie, deleteAction: {
                                if let index = viewModel.movies.firstIndex(where: { $0.id == movie.id }) {
                                    viewModel.deleteMovie(at: IndexSet(integer: index))
                                }
                            })
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .navigationTitle("List of Movies")
            .onAppear {
                viewModel.fetchMovies()
            }
        }
    }
}

struct MovieGridItem: View {
    var movie: Movie
    var deleteAction: () -> Void
    
    var body: some View {
        VStack(alignment: .leading) {
            moviePoster
            
            Text(movie.title)
                .fontWeight(.semibold)
                .lineLimit(1)
                .padding([.top, .bottom], 4)
            
            HStack {
                ForEach(0..<5) { _ in
                    Image(systemName: "star.fill")
                        .foregroundColor(.white)
               // Text("If you want to delete the move from the list, just press trash icon")
                }
                
                Spacer()
                
                Button(action: deleteAction) {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                }
            }
            .font(.caption)
        }
      //  .frame(width: 150, height: 275) // Increased height to accommodate the delete button
        .background(Color(.systemBackground))
        .cornerRadius(8)
        .shadow(radius: 4)
    }
    
    @ViewBuilder
    private var moviePoster: some View {
        NavigationLink(destination: MovieDetailView(movie: movie)) {
            if let posterPath = movie.posterPath, let url = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)") {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .success(let image):
                        image.resizable()
                             .aspectRatio(contentMode: .fill)
                             .frame(width: 150, height: 225)
                             .clipped()
                    case .failure:
                        Image(systemName: "film")
                            .font(.title)
                            .frame(width: 150, height: 225)
                    @unknown default:
                        EmptyView()
                    }
                }
            } else {
                Image(systemName: "film")
                    .font(.title)
                    .frame(width: 150, height: 225)
            }
        }
    }
}

extension MovieListViewModel {
    func deleteMovie(at offsets: IndexSet) {
        movies.remove(atOffsets: offsets)
    }
}



/*
struct MovieListView: View {
    @ObservedObject var viewModel = MovieListViewModel()

    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.movies) { movie in
                    NavigationLink(destination: MovieDetailView(movie: movie)) {
                        MovieRow(movie: movie)
                    }
                }
                .onDelete(perform: deleteMovies)
            }
            .navigationTitle("Now Playing")
        }
        .onAppear {
            viewModel.fetchMovies()
        }
        .toolbar {
            EditButton()
        }
    }

    private func deleteMovies(at offsets: IndexSet) {
        viewModel.movies.remove(atOffsets: offsets)
    }
}
 */



