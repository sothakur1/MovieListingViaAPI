//
//  MovieDetailView.swift
//  MovieList
//
//  Created by Sohan Ramesh Thakur on 2/25/24.
//

import Foundation

import SwiftUI

struct MovieDetailView: View {
    var movie: Movie

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {  // Align content to the leading edge
                movieImages
                    .padding(.bottom)

                movieTitle
                movieRating
                    .padding(.vertical)

                movieOverview
                Spacer()
            }
            .padding(.horizontal)  // Add horizontal padding for the entire VStack
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
    
    @ViewBuilder
    private var movieImages: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach([movie.posterPath, movie.backdropPath], id: \.self) { imagePath in
                    if let imagePath = imagePath, let url = URL(string: "https://image.tmdb.org/t/p/w500\(imagePath)") {
                        AsyncImage(url: url) { image in
                            image.resizable()
                                 .scaledToFit()
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(height: 300)
                        .cornerRadius(8)
                    }
                }
            }
        }
    }
    
    private var movieTitle: some View {
        Text(movie.title)
            .font(.title2)
            .fontWeight(.bold)
            .padding(.top)
    }
    
    private var movieRating: some View {
        HStack {
            Text("Rating: ")
                .fontWeight(.semibold)
            ForEach(0..<Int(movie.voteAverage / 2), id: \.self) { _ in
                Image(systemName: "star.fill").foregroundColor(.yellow)
            }
            Spacer()  // Push content to the left
        }
    }
    
    private var movieOverview: some View {
        Text(movie.overview)
            .padding(.vertical)
    }
}


/*
import SwiftUI

struct MovieDetailView: View {
    var movie: Movie

    var body: some View {
        ScrollView {
            VStack {
                // Horizontal ScrollView for Images
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach([movie.posterPath, movie.backdropPath], id: \.self) { imagePath in
                            if let imagePath = imagePath, let url = URL(string: "https://image.tmdb.org/t/p/w500\(imagePath)") {
                                AsyncImage(url: url) { image in
                                    image.resizable()
                                         .scaledToFit()
                                } placeholder: {
                                    ProgressView()
                                }
                                .frame(height: 300)
                                .cornerRadius(8)

                            }
                        }
                        
                        if let posterPath = movie.posterPath, let url = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)") {
                            AsyncImage(url: url) { image in
                                image.resizable()
                                    .scaledToFill()
                            } placeholder: {
                                ProgressView()
                            }
                            .frame(width: 100, height: 150)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.gray, lineWidth: 2))
                            .shadow(radius: 7)
                        }
                    }
                }
                .padding(.vertical)

                Text(movie.title)
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()

                HStack {
                    ForEach(0..<Int(movie.voteAverage / 2), id: \.self) { _ in
                        Image(systemName: "star.fill").foregroundColor(.yellow)
                    }
                }
                .padding()
                
//                    Text("Release Date: \(movie.releaseDate)")
//                        .font(.headline)
//                        .padding()
//                    
//                Text("Popularity: \(movie.popularity, specifier: "%.2f")").font(.subheadline).padding()
//                    
//                    Text("Vote Average: \(movie.voteAverage, specifier: "%.2f") (\(movie.voteCount) votes)")
//                        .font(.subheadline)
//                        .padding()
                    
                Text(movie.overview)
                    .padding()

                Spacer()
            }
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
*/
